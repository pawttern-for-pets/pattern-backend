import {
  useState,
  type FormEvent,
} from 'react'

import type {
  PatternDocument,
} from '../cad/document'

import {
  createBodyMeasurementsFromCm,
} from '../pattern/measurements'

import {
  createReferenceTankArmholeConstruction,
} from '../pattern/referenceTankArmholeConstruction'

interface PatternInputPanelProps {
  onGenerate: (
    document: PatternDocument,
  ) => void
}

function parseMeasurement(
  value: string,
  label: string,
): number {
  const parsed =
    Number(value)

  if (
    !Number.isFinite(parsed) ||
    parsed <= 0
  ) {
    throw new Error(
      `${label} must be greater than 0 cm.`,
    )
  }

  return parsed
}

export function PatternInputPanel({
  onGenerate,
}: PatternInputPanelProps) {
  /*
   * Reference-video values are
   * prefilled for our first visual
   * validation.
   *
   * The user can freely replace them.
   */
  const [
    backLengthInput,
    setBackLengthInput,
  ] = useState('22')

  const [
    chestGirthInput,
    setChestGirthInput,
  ] = useState('36')

  const [
    neckGirthInput,
    setNeckGirthInput,
  ] = useState('27')

  const [
    message,
    setMessage,
  ] = useState<string | null>(
    null,
  )

  const handleSubmit = (
    event:
      FormEvent<HTMLFormElement>,
  ) => {
    event.preventDefault()

    try {
      const backLengthCm =
        parseMeasurement(
          backLengthInput,
          'Back Length',
        )

      const chestGirthCm =
        parseMeasurement(
          chestGirthInput,
          'Chest Girth',
        )

      const neckGirthCm =
        parseMeasurement(
          neckGirthInput,
          'Neck Girth',
        )

      /*
       * Raw dog measurements only.
       *
       * No automatic ease.
       * No automatic allowance.
       */
      const measurements =
        createBodyMeasurementsFromCm({
          backLengthCm,
          chestGirthCm,
          neckGirthCm,
        })

      /*
       * Generate only the verified
       * foundation geometry we have
       * built so far.
       */
      const construction =
        createReferenceTankArmholeConstruction(
          measurements,
        )

      onGenerate(
        construction.document,
      )

      setMessage(
        'Base block generated.',
      )
    } catch (error) {
      const errorMessage =
        error instanceof Error
          ? error.message
          : 'Unable to generate the base block.'

      setMessage(
        errorMessage,
      )
    }
  }

  return (
    <section
      style={{
        padding: '12px 16px',
        borderBottom:
          '1px solid #d7d7d7',
        background: '#ffffff',
      }}
    >
      <form
        onSubmit={
          handleSubmit
        }
      >
        <div
          style={{
            display: 'flex',
            alignItems: 'end',
            gap: '12px',
            flexWrap: 'wrap',
          }}
        >
          <div>
            <strong>
              Sleeveless Master Block
            </strong>

            <div
              style={{
                fontSize: '12px',
                marginTop: '2px',
              }}
            >
              Dog measurements in cm
            </div>
          </div>

          <label>
            <div>
              Back Length (B)
            </div>

            <input
              type="number"
              min="0.1"
              step="0.1"
              inputMode="decimal"
              value={
                backLengthInput
              }
              onChange={(
                event,
              ) =>
                setBackLengthInput(
                  event.target.value,
                )
              }
              style={{
                width: '90px',
              }}
            />
          </label>

          <label>
            <div>
              Chest Girth (C)
            </div>

            <input
              type="number"
              min="0.1"
              step="0.1"
              inputMode="decimal"
              value={
                chestGirthInput
              }
              onChange={(
                event,
              ) =>
                setChestGirthInput(
                  event.target.value,
                )
              }
              style={{
                width: '90px',
              }}
            />
          </label>

          <label>
            <div>
              Neck Girth (N)
            </div>

            <input
              type="number"
              min="0.1"
              step="0.1"
              inputMode="decimal"
              value={
                neckGirthInput
              }
              onChange={(
                event,
              ) =>
                setNeckGirthInput(
                  event.target.value,
                )
              }
              style={{
                width: '90px',
              }}
            />
          </label>

          <button
            type="submit"
          >
            Generate Base Block
          </button>

          {message && (
            <span
              style={{
                fontSize:
                  '13px',
              }}
            >
              {message}
            </span>
          )}
        </div>
      </form>
    </section>
  )
}
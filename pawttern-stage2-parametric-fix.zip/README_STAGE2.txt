PAWTTERN Stage 2 - Parametric Project Foundation

This package supersedes the earlier Stage 1 fix.

Changes:
- PatternProject schema v2
- B/C/N + half-body allowance + CAD document travel together through Undo/Redo
- New project default half-body allowance = +10 mm (+1 cm), matching the reference video
- Raw Chest Girth C remains unchanged
- Save/Open preserves measurements, allowance, and geometry
- Legacy geometry-only and v1 project files migrate without inventing the new +1 cm allowance
- Canvas point labels use smaller two-line text

Copy the included src folder into the ROOT pawttern-cad project folder and replace/merge files.
Then run:
  npm.cmd test
  npm.cmd run build

Do not commit until functional Generate -> Undo -> Redo -> Save -> Open checks pass.
